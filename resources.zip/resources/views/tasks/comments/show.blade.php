@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Comentariu pentru sarcina: {{ $task->title }}</h2>
    
    <div class="comment-detail">
        <p>{{ $comment->content }}</p>
        <small>{{ $comment->created_at->diffForHumans() }}</small>
    </div>
    
    <a href="{{ route('tasks.comments.index', $task->id) }}" class="btn btn-secondary">Înapoi la comentarii</a>
</div>
@endsection