@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Comentarii pentru sarcina: {{ $task->title }}</h2>
    
    <div class="comments-section">
        @foreach($task->comments as $comment)
            <div class="comment-card">
                <p>{{ $comment->content }}</p>
                <small>{{ $comment->created_at->diffForHumans() }}</small>
            </div>
        @endforeach
    </div>
</div>
@endsection