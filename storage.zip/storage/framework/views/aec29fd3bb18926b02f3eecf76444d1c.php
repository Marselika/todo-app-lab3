<div class="task-card">
    <h2><?php echo e($task->title); ?></h2>
    
    <?php if($task->status): ?>
        <span class="task-status <?php echo e($task->completed ? 'status-completed' : 'status-active'); ?>">
            <?php echo e($task->completed ? 'Completat' : 'Activ'); ?>

        </span>
    <?php endif; ?>
    
    <div class="task-info">
        <p><?php echo e($task->description); ?></p>
        
        <?php if($task->category): ?>
            <p>
                <strong>Categoria:</strong>
                <span class="badge"><?php echo e($task->category->name); ?></span>
            </p>
        <?php endif; ?>
        
        <p>
            <strong>Prioritate:</strong>
            <span class="badge priority-<?php echo e(strtolower($task->priority)); ?>">
                <?php echo e($task->priority); ?>

            </span>
        </p>
        
        <?php if($task->tags->count() > 0): ?>
            <div class="tags-container">
                <?php $__currentLoopData = $task->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="tag"><?php echo e($tag->name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="task-actions">
        <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-details">Vezi detalii</a>
        <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-edit">Editează</a>
        <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-delete" onclick="return confirm('Ești sigur?')">Șterge</button>
        </form>
    </div>
</div><?php /**PATH C:\xampp\todo-app\resources\views/components/task-card.blade.php ENDPATH**/ ?>