

<?php $__env->startSection('title', 'Acasă'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Bine ați venit la To-Do App</h1>
    
    <p>Organizați-vă sarcinile și colaborați eficient cu echipa dumneavoastră.</p>

    <nav>
        <h2>Navigație rapidă:</h2>
        <ul>
            <li><a href="<?php echo e(route('tasks.index')); ?>">Lista de sarcini</a></li>
            <li><a href="<?php echo e(route('tasks.create')); ?>">Crearea unei sarcini noi</a></li>
        </ul>
    </nav>

    <section>
        <h2>Despre aplicația noastră</h2>
        <p>To-Do App pentru echipe este o aplicație simplă și eficientă pentru gestionarea sarcinilor în cadrul echipelor. Principalele funcții includ:</p>
        <ul>
            <li>Crearea și atribuirea sarcinilor</li>
            <li>Urmărirea progresului</li>
            <li>Colaborare în timp real</li>
            <li>Notificări și termene limită</li>
        </ul>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\todo-app\resources\views/home.blade.php ENDPATH**/ ?>