

<?php $__env->startSection('title', 'Create Task'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Create New Task</h1>
    <!-- Adăugați aici formularul pentru crearea unui nou task -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\todo-app\resources\views/tasks/create.blade.php ENDPATH**/ ?>