<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['priority']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['priority']); ?>
<?php foreach (array_filter((['priority']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$colorClass = match(strtolower($priority)) {
    'scăzută' => 'priority-low',
    'medie' => 'priority-medium',
    'ridicată' => 'priority-high',
    default => 'priority-default'
};

$icon = match(strtolower($priority)) {
    'scăzută' => '▼',
    'medie' => '▶',
    'ridicată' => '▲',
    default => '•'
};
?>

<span class="task-priority <?php echo e($colorClass); ?>">
    <?php echo e($icon); ?> <?php echo e($priority); ?>

</span><?php /**PATH C:\xampp\todo-app\resources\views/components/task-priority.blade.php ENDPATH**/ ?>