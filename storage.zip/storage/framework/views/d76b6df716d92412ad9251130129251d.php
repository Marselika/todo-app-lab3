

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Editează Sarcina</h1>

        <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="mb-3">
                <label for="title" class="form-label">Titlu</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo e($task->title); ?>" required>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Descriere</label>
                <textarea class="form-control" id="description" name="description" rows="3"><?php echo e($task->description); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="category_id" class="form-label">Categoria</label>
                <select class="form-control" id="category_id" name="category_id">
                    <option value="">Selectează categoria</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($task->category_id == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Etichete</label>
                <div>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="tags[]" 
                                   value="<?php echo e($tag->id); ?>" id="tag<?php echo e($tag->id); ?>"
                                   <?php echo e($task->tags->contains($tag->id) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="tag<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Actualizează Sarcina</button>
            <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-secondary">Anulează</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\todo-app\resources\views/tasks/edit.blade.php ENDPATH**/ ?>