<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Models\Category;
use App\Models\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = Task::with(['category', 'tags'])->latest()->get();
        return view('tasks.index', compact('tasks'));
    }

    public function show($id)
    {
        $task = Task::with(['category', 'tags', 'comments'])->findOrFail($id);
        return view('tasks.show', compact('task'));
    }

    public function create()
    {
        $categories = Category::all();
        $tags = Tag::all();
        return view('tasks.create', compact('categories', 'tags'));
    }

    public function store(Request $request)
    {
        return DB::transaction(function () use ($request) {
            $task = Task::create([
                'title' => $request->input('title'),
                'description' => $request->input('description'),
                'category_id' => $request->input('category_id')
            ]);

            if ($request->has('tags')) {
                $task->tags()->attach($request->input('tags'));
            }

            return redirect()->route('tasks.show', $task->id)
                ->with('success', 'Sarcina a fost creată cu succes!');
        });
    }

    public function edit($id)
    {
        $task = Task::with(['category', 'tags'])->findOrFail($id);
        $categories = Category::all();
        $tags = Tag::all();
        return view('tasks.edit', compact('task', 'categories', 'tags'));
    }

    public function update(Request $request, $id)
    {
        $task = Task::findOrFail($id);
        
        $task->update([
            'title' => $request->input('title'),
            'description' => $request->input('description'),
            'category_id' => $request->input('category_id')
        ]);

        $task->tags()->sync($request->input('tags', []));

        return redirect()->route('tasks.show', $task->id)
            ->with('success', 'Sarcina a fost actualizată cu succes!');
    }

    public function destroy($id)
    {
        $task = Task::findOrFail($id);
        $task->tags()->detach(); // Elimină relațiile cu tag-urile
        $task->delete();

        return redirect()->route('tasks.index')
            ->with('success', 'Sarcina a fost ștearsă cu succes!');
    }

        public function showComments($taskId)
    {
        $task = Task::with('comments')->findOrFail($taskId);
        return view('tasks.comments.index', compact('task'));
    }

    public function addComment(Request $request, $taskId)
    {
        $task = Task::findOrFail($taskId);
        
        $comment = $task->comments()->create([
            'content' => $request->input('content')
        ]);

        return redirect()->back()->with('success', 'Comentariul a fost adăugat cu succes!');
    }

    public function showComment($taskId, $commentId)
    {
        $task = Task::findOrFail($taskId);
        $comment = $task->comments()->findOrFail($commentId);
        
        return view('tasks.comments.show', compact('task', 'comment'));
    }
}